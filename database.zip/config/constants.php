<?php
// config/constants.php

return [
    'API_BASE_URL' => 'https://uat-api.globaltix.com/api/',
    'API_IMAGE_URL' => 'https://product-image.globaltix.com/uat-gtImage/'
];
