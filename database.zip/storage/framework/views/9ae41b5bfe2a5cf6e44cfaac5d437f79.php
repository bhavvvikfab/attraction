<!-- Partial view: partials/transaction_table.blade.php -->

<table class="table table-borderless datatable top-table">
    <thead>
        <tr>
            <th> Sr. No. </th>
            <?php if(Auth::user()->role == 1): ?>
            <th> Agent </th>
            <?php endif; ?>
            <th> Request No. </th>
            <th data-type="date" data-format="DD/MM/YYYY">Request Date</th>
            <th>Amount</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key + 1); ?></td>
            <?php if(Auth::user()->role == 1): ?>
            <td> <?php echo e($transaction->user->name); ?> </td>
            <?php endif; ?>
            <td><?php echo e($transaction->transaction_id); ?></td>
            <td><?php echo e($transaction->created_at->format('Y-m-d H:i')); ?></td>
            <td><?php echo e($transaction->amount); ?></td>
            <td>
                
                <?php if($transaction->status == "pending"): ?>
                    <?php if(Auth::user()->role == 1): ?>
                    <select class="btn btn-warning text-start" name="topup-request" id="topup-request" data-id="<?php echo e($transaction->id); ?>">
                        <option value="pending">Requested</option>
                        <option value="completed">Approved</option>
                        <option value="failed">Reject</option>                              
                    </select>
                    <?php else: ?>
                        <button type="button" class="btn btn-warning">Pending</button>
                    <?php endif; ?>
                <?php elseif($transaction->status == "completed"): ?>
                <button type="button" class="btn btn-success">Approved</button>
                <?php else: ?>
                <button type="button" class="btn btn-danger">Rejected</button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\xampp_attraction\htdocs\attraction\resources\views/topup/partials/transaction_table.blade.php ENDPATH**/ ?>